import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'product_model.dart';

class ProductService {
  static const String _baseUrl = "https://api.escuelajs.co/api/v1/products";

  static Future<List<ProductModel>> getAPI() async {
    final res = await http.get(Uri.parse(_baseUrl));
    if (res.statusCode == 200) {
      return compute(_convert, res.body);
    } else {
      throw Exception('Failed to load products');
    }
  }
}

List<ProductModel> _convert(String body) {
  List<ProductModel> data = productModelFromJson(body);
  return data;
}
